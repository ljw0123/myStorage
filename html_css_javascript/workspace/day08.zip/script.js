let hw = document.getElementById('hw');
hw.addEventListener('click', function(){
    alert("Hello World");
});