package method;

public class Main01 {
	public static int add(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
		int result = add(5, 7);
		System.out.println("두 수의 합: " + result);
	}

}






















