package todolist;

import java.util.Calendar;
import java.util.Scanner;


public class TimeBlockMain{
  public static void main (String args[]){
	  DataPrinter n = new DataPrinter();
	  n.act();

  }
}