package loop;

public class Main03 {

	public static void main(String[] args) {
		// 구구단 7단, while문
		int j = 0;
		int i = 100;
		
		while(i<10) {
			j = 7 * i;
			System.out.println(j);
			i++;
		}
		
	}

}






