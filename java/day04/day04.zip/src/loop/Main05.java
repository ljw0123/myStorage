package loop;

public class Main05 {

	public static void main(String[] args) {
		// 구구단 7단. do~while
		int j = 0;
		int i = 1;
		
		do {
			j = 7 * i;
			System.out.println(j);
			i++;
		}while(i <= 9);
		
	}

}





