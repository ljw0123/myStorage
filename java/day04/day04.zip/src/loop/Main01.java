package loop;

public class Main01 {

	public static void main(String[] args) {
		// 구구단 7단,40분까지  
		int j = 0;
		for(int i=1; i<10; i++ ) {
			j = 7 * i;
			System.out.println(j);
		}
	}

}





