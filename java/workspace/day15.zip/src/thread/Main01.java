package thread;

public class Main01 {

	public static void main(String[] args) {
		ThreadTest t1 = new ThreadTest();
		t1.start();
		
	}

}







