package thread;

public class Main02 {

	public static void main(String[] args) {
		RunnableTest ru1 = new RunnableTest();
		ru1.run();
		
	}

}







