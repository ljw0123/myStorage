package method;

public class Main06 {
	// error발생
//	public static void main(String[] args) {
//		System.out.println(f2(100));
//	}
//	public static void f1(int x) {
//		int result = x + 1;
//	}
//	public static int f2(int x) {
//		return f1(x) + 1;
//	}
}








