package method;

public class Main01 {

	public static void main(String[] args) {
		plus();
		minus();
		plus();
		minus();
	}
	
	public static void plus() {
		int num = 10;
		int num2 = 20;
		System.out.println(num + num2);
	}
	public static void minus() {
		int num = 50;
		int num2 = 10;
		System.out.println(num - num2);
	}

}















