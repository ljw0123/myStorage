package method;

public class Main02 {

	public static void main(String[] args) {
		print(5);
		//print();		// error
		//print(true);	// error
		//print(10,20);	// error
	}

	public static void print(int num) {
		System.out.println(num);
	}
}







