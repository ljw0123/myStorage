package hiding;

public class Main02 {

	public static void main(String[] args) {
		Article a1 
			= new Article(1, "자바게시물1", "javabeans란?", 
						"자바학생", 123, "2023-12-26");
		System.out.println(a1.toString());
		
		
//		System.out.println(a1.getSeq());
//		System.out.println(a1.getSubject());
//		System.out.println(a1.getConent());
//		System.out.println(a1.getWriter());
//		System.out.println(a1.getHit());
//		System.out.println(a1.getRegDate());
	}

}


















