package Abstract;

public class Army extends Unit{

	public Army(String name) {
		super(name);
	}

	@Override
	public void attck() {
		System.out.println(this.getName() 
								+ ">>육상공격");
	}
	@Override
	public void move() {
		System.out.println(this.getName() 
								+ ">>육상이동");
	}
	
	
	/*
	 * 1. Unit class 상속
	 * 2. 메소드 재 구현
	 *    attack() 	-> 이름(Unit 생성자) + ">>육상공격" 
	 *    move() 	-> 이름(Unit 생성자) + ">>육상이동"
	 */
}


















