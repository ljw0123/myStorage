package val;

public class Main01 {
	public static void main(String[] args) {
		System.out.println("두번째 시간");
	}
}
