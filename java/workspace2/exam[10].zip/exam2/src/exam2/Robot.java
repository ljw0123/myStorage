package exam2;

public class Robot {
	// 데이터가 없는게 맞습니다.화이팅:)
}
