package exam2;

public class DanceRobot extends Robot {
	void dance() {
		//1. "춤을 춥니다 ."를 출력한다.
		System.out.println("충을 춥니다.");
	}
}
