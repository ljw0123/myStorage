package exam2;

public class DrawRobot extends Robot {
	void draw() {
		//2."그림을 그립니다." 를 출력한다.
		System.out.println("그림을 그립니다.");
	}
}
