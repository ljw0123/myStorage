package exam2;

public class SingRobot extends Robot {
	void sing() {
		//3. "노래를 합니다." 를 출력한다.
		System.out.println("노래를 합니다.");
	}
}
