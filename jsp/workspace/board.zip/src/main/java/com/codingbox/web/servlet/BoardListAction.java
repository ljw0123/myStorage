package com.codingbox.web.servlet;

import java.util.List;

import com.codingbox.web.action.Action;
import com.codingbox.web.action.ActionForward;
import com.codingbox.web.dao.BoardDAO;
import com.codingbox.web.dto.BoardDTO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BoardListAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) {
		ActionForward forward = new ActionForward();
		BoardDAO bdao = new BoardDAO();
		request.setAttribute("boardList", bdao.getBoardList());
        forward.setRedirect(false);
        forward.setPath(request.getContextPath() + "/board/boardlist.jsp");
		
		return forward;
	}

}