package com.codingbox.web.vo;

public class User {
	public String userid;
	public String username;
	public int age;
	
	public User(String userid, String username, int age) {
		super();
		this.userid = userid;
		this.username = username;
		this.age = age;
	}
	
	
}
